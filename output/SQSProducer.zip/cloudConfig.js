const cloudConfig = {
    stage: "dev",
    region: "us-east-1",
    userPoolArn: "arn:aws:cognito-idp:us-east-1:388412347424:userpool/us-east-1_d8rcMtMXj",
    commonLibArn: "arn:aws:lambda:us-east-1:388412347424:layer:commonLibs:6",
    userTableArn: 'arn:aws:dynamodb:us-east-1:388412347424:table/MufUser',
    feedSNSTopicARN: 'arn:aws:sns:us-east-1:388412347424:SNSFeed-dev',
    FeedSNSDLQArn: 'arn:aws:sqs:us-east-1:388412347424:SNSFeedDLQ-dev',
    MufSQSQueUrl: 'arn:aws:sqs:us-east-1:388412347424:MufSQS-dev',
};

module.exports = cloudConfig;